package Columns;

import java.util.List;
import hw3.Bead;

public interface UpdatableComponent {
	void update(List<Bead> Bunch,String s,int i);
}
